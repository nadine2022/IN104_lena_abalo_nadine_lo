from django.urls import path
from . import views

app_name = 'detector'
urlpatterns = [
    path('detector/', views.det, name='detector'),
]
