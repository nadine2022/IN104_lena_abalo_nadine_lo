from django.db import models

class detect(models.Model):
    url = models.URLField(verbose_name="Enter news here", unique=True)
    score = models.IntegerField(default=0, 
                                   verbose_name="Nombre d'accès à l'URL")

    def __str__(self):
        return "{1}".format(self.url)

   
