from django import forms
from .models import detect 

class detectForm(forms.ModelForm):
    class Meta:
        model = detect
        fields = ('url',)
