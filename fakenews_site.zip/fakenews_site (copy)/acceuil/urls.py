from django.urls import path
from . import views

app_name = 'acceuil'
urlpatterns = [
    path('date', views.date_actuelle),
]
