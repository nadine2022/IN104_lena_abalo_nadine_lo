from django.db import models

#Modele pour l'information récupérée de l'utilisateur
class detect(models.Model):
    info = models.CharField(max_length = 100, default='')
    
#Modele pour le score 
class score(models.Model):
    score = models.IntegerField(verbose_name = "News score")



   
