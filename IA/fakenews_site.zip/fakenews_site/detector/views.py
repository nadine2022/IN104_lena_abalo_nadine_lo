from django.shortcuts import render, redirect
from .forms import detectForm
from .models import detect, score
from .score import give_score 

#Vue pour la page home
def home(request):
 
    
    return render(request, 'detector/home.html')

#Vue du détecteur
def det(request):
    form = detectForm()
    news = detect() #Variable qui contiendra ce que l'utilisateur entre
    if request.method == 'POST':
        form = detectForm(request.POST)
        if form.is_valid():
            news=detect(info=form.cleaned_data["info"])
            news.save()
            post = form.cleaned_data["info"]
            return redirect('scores', post)
    N = {'N' : form, 'news' : news}
    return render(request, 'detector/det.html', N)

    

def scores(request,inf):
    news =  detect.objects.filter(info=inf)
    news.info = inf
    score = give_score(inf)
    N = {'N' : news, 'score' : score}
    return render(request, 'detector/scores.html', N)

