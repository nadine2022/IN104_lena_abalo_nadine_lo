from django.apps import AppConfig


class DetectorConfig(AppConfig):
    name = 'detector'
