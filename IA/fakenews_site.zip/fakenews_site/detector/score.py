def give_score(inf):
    return 1
