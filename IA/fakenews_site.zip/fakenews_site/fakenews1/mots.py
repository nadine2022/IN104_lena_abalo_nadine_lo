import string
from apinews1 import nombre_articles
# -*- coding: utf-8-*-
def selection():

    fact=input('Rentrez une phrase:') #On veut detecter les mots cles à changer avec les donnees de l'utilisateur
    L=fact.split()

    #Separer les points de ponctuation des mots
    for i,x in enumerate(L):
        n=len(L[i])
        if L[i][n-1] in string.punctuation :
            L[i]=L[i][:n-1]

    T=L[:] #copie de L
            #on fait le tri, on enleve ponctuation, adjectifs, adverbes, mots courts

    for i,x in enumerate(L):

    #elimination des mots courts(sauf les sigles), ponctuation et chiffres
        if ((len(x)<4) and (x[len(x)-1] not in string.ascii_uppercase)):
            T.pop(T.index(x))
        
        n=len(x)

        #elimination d'une partie d'adjectifs, d'adverbes
    
        terminaison_2_lettres=["ly","ed","al","er"]
        terminaison_3_lettres=["ive","ful","ble","ant","ing"]
        terminaison_4_lettres=["less"]

        if x[n-2:n] in terminaison_2_lettres :
            T.pop(T.index(x))
        if x[n-3:n] in terminaison_3_lettres :
            T.pop(T.index(x))
        if x[n-4:n] in terminaison_4_lettres :
            T.pop(T.index(x))


    # selection des mots-cles en utilisant apinews1
    mots_cles=[]
    for x in T:
        if (nombre_articles(x)<=60000):
            mots_cles.append(x)

    return(mots_cles) # les mots les plus importants

def mots_cles_a_chercher(mots_cles):
    s=""

    for i in mots_cles:
        s=s+i+" "
    print(s)
    return (nombre_articles(s))
    
