from datetime import datetime
from django.shortcuts import render

def date_actuelle(request):
    return render(request, 'acceuil/date.html', {'date': datetime.now()})

